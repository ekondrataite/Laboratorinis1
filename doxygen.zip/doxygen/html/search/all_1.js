var searchData=
[
  ['studentas_1',['studentas',['../classstudentas.html',1,'']]]
];
