var searchData=
[
  ['studentas_3',['studentas',['../classstudentas.html',1,'']]]
];
